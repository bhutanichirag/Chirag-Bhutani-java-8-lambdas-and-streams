# Khyati-Java-8-Lambdas-and-Streams
EPAM assignment
